// number example
var num1 = 40;
output = " Number is : "+ num1;
console.log(output);
document.getElementById('display').innerHTML = output;


// String Examples
var myName = "JhonnyTrainer";
output = " The is a String : " + myName;
console.log(output);
document.getElementById('display').innerHTML = output;

// boolean Examples
var isJSEasy = true;
output = " The is a Boolean : " + isJSEasy;
console.log(output);
document.getElementById('display').innerHTML = output;

// reassignment example of variables
var a = 10; //number
a = "JhonnyTrainer"; //string
a = true; //Boolean


// Undefined Example
var unDefine;
output = "this is the undefined : "+ unDefine;
console.log(output);
document.getElementById('display').innerHTML=output;


//only declared variables the default value is Undefined
var something;
output = " value is Undefined : " + something;
console.log(output);
document.getElementById('display').innerHTML = output;


// null example
var num2 = null;
output = "null example is : " + num2;
console.log(output);
document.getElementById('display').innerHTML = output;


/**  Copy Right @ jani.reddy5@gmail.com  */